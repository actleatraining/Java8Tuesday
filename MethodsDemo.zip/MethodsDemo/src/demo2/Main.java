package demo2;

import demo1.AnotherClass;

public class Main {

    public static void main(String[] args) {

        int sum1 = getNumberOfNumbers(); // ok to send no values

        int sum2 = getNumberOfNumbers(4,88); // ok to send two comma separated values

        int sum3 = getNumberOfNumbers(-1, -55, 98, 0); // ok to send four comma separated values

        int[] array = {5,88,999,1,-2,44};

        int sum4 = getNumberOfNumbers(array); // ok to send an array with values


        System.out.println(sum1);
        System.out.println(sum2);
        System.out.println(sum3);
        System.out.println(sum4);

    }


    // Method that takes a varargs argument - numbers will become an int array
    private static int getNumberOfNumbers(int... numbers) {
        return numbers.length;
    }
}
