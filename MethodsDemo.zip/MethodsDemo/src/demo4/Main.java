package demo4;

public class Main {

    public static void main(String[] args) {

        // Normal for loop
        for (int i = 1; i <=10;i++) {
            System.out.print(i + " ");
        }

        System.out.println(); // Just creating a new line

        // Using a recursive method
        printNumber(1);
    }

    private static void printNumber(int number) {
        if (number <= 10) { // Condition that will end the recursion
            System.out.print(number + " ");
            printNumber(number+1); // Recursive call
        }
    }
}
