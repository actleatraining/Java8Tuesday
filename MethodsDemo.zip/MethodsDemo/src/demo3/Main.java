package demo3;

public class Main {

    public static void main(String[] args) {

        int number = add(4,6);

        double number2 = add(4.4, 7.7);

        String text = add("Hello " , "World!");

        System.out.println(number);
        System.out.println(number2);
        System.out.println(text);
    }

    private static int add(int a, int b) {
        return a + b;
    }

    private static double add(double a, double b) {
        return a + b;
    }

    private static String add(String a, String b) {
        return a + b;
    }

}
