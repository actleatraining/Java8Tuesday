package demo1;

public class Main {

    public static void main(String[] args) {

        // Calling a method with no return and a String as input argument
        printMethod("Print this!");

        // Calling a method with an int return type and two ints as input arguments
        int sum = add(5, 7); // Assigns the return value to the variable sum

        // Can call this public method in another Class
        AnotherClass.publicMethod();

        // Can't call this private method in another Class
        //demo1.AnotherClass.privateMethod();

    }

    // Method that takes a String as input argument and doesn't return anything
    public static void printMethod(String text) {
        System.out.println(text);
    }

    // Method that takes two ints as input arguments and returns an int
    private static int add(int number1, int number2) {
        return number1 + number2;
    }
}
