import java.util.Arrays;

public class ArraysDemo3 {

    public static void main(String[] args) {
        int[] numbers3 = {5,3,8,6,1};

        System.out.println("printing the elements with a for loop:");
        for (int i = 0; i < numbers3.length; ++i) {
            System.out.println("Number: " + numbers3[i]);
        }

        System.out.println("printing the elements with a for each loop:");
        for (int number : numbers3) {
            System.out.println("Number: " + number);
        }

        // Find the highest number with the for loop
        int highestSoFar = numbers3[0];
        for (int i = 1; i < numbers3.length; ++i) {
            int current = numbers3[i];
            if (current > highestSoFar) {
                highestSoFar = current;
            }
        }
        System.out.println("Highest number in this array: " + Arrays.toString(numbers3) + " is " + highestSoFar);

        // Find the highest number with the for each loop
        highestSoFar = numbers3[0];
        for (int current : numbers3) {
            if (current > highestSoFar) {
                highestSoFar = current;
            }
        }
        System.out.println("Highest number in this array: " + Arrays.toString(numbers3) + " is " + highestSoFar);

    }
}
