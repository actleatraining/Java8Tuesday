import java.util.Arrays;

public class ArraysDemo4 {

    public static void main(String[] args) {
        String[][] cities = {{"Paris", "Nice"},
                {"London", "Manchester"},
                {"Berlin", "Bern"}};

        String city1 = cities[0][0]; // Paris
        String city2 = cities[1][0]; // London
        String city3 = cities[0][1]; // Nice

        System.out.println(city1);
        System.out.println(city2);
        System.out.println(city3);
    }
}
