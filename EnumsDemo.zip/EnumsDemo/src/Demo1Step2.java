public class Demo1Step2 {
    public static void main(String[] args) {

        Status status = Status.LOW; // only 1, 2 or 3 are valid values for status

        if (status == Status.HIGH) {
            System.out.println("High status!");
        }
        else if (status == Status.MEDIUM){
            System.out.println("Medium status!");
        }
        else if (status == Status.LOW) {
            System.out.println("Low status");
        }
        // Doesn't need an else here because status could not have any other value than the valid ones!
    }
}