public enum Status {
    HIGH, MEDIUM, LOW
}
