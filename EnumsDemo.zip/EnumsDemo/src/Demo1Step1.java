public class Demo1Step1 {
    public static void main(String[] args) {

        int status = 1; // only 1, 2 or 3 are valid values for status

        if (status == 1) {
            System.out.println("High status!");
        }
        else if (status == 2){
            System.out.println("Medium status!");
        }
        else if (status == 3) {
            System.out.println("Low status");
        }
        else {
            System.out.println("Invalid status!"); // the value of status could be any number!
        }
    }
}