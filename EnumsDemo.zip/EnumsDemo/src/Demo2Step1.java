public class Demo2Step1 {
    public static void main(String[] args) {

        Status status = Status.LOW; // only 1, 2 or 3 are valid values for status

        switch (status) {
            case HIGH :
                System.out.println("High status!");
                break;
            case MEDIUM:
                System.out.println("Medium status!");
                break;
            case LOW:
                System.out.println("Low status!");
                break;
            // Doesn't need a default here because status could not have any other value than the valid ones!
        }

    }
}