public class Demo2Step2 {
    public static void main(String[] args) {

        for (Status status : Status.values()) {
            System.out.println(status);
        }
    }
}