public class Main {
    public static void main(String[] args) {

        Movie movie1 = new Movie("Ghostbusters", Genre.Comedy, "Ivan Reitman");
        System.out.println(movie1.getGenre());

        switch (movie1.getGenre()) {
            case Comedy :
                System.out.println("It's a comedy!");
                break;
            case Drama :
                System.out.println("It's a drama!");
                break;
            case Action :
                System.out.println("It's a action!");
                break;
        }
    }
}