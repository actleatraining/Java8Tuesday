public enum Genre {
    Comedy, Drama, Action
}
