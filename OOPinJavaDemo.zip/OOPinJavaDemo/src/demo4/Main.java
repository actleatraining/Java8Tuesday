package demo4;

public class Main {
    public static void main(String[] args) {
        // primitive type
        int number1 = 5;

        // Wrapper type - object
        Integer number2 = 8;

        System.out.println(number1);
        System.out.println(number2);

        // primitive types always have a value - they can't have null as a value
        //number1 = null;

        // wrapper types, being objects, can have null as value
        number2 = null; // number2 now has no value

        System.out.println(number2);

        number2 = 8; // better put a value back in the variable

        // Helper methods - static method comparing two int values
        if (Integer.compare(number1, number2) < 0) {
            System.out.println("number1 is smallest");
        }
        else if (Integer.compare(number1, number2) > 0) {
            System.out.println("number2 is smallest");
        }
        else {
            System.out.println("The numbers are equal");
        }

        // Helper methods - instance method comparing the value of an Integer with another Integer value
        if (number2.compareTo(number1) < 0) {
            System.out.println("number2 is smallest");
        }
        else if (number2.compareTo(number1) > 0) {
            System.out.println("number1 is smallest");
        }
        else {
            System.out.println("The numbers are equal");
        }

        // Conversion method - from String to int
        int numberFromString = Integer.parseInt("314");
        System.out.println(numberFromString);

        // Conversion method - from int to String
        String stringFromNumber = Integer.toString(712);
        System.out.println(stringFromNumber);

    }
}
