package demo3;

public class Stove {
    private Pot pot;

    void setPot(Pot pot) {
        this.pot = pot;
    }

    public void turnOn() {
        if (pot != null) {
            pot.setIsHot(true);
        }
    }
}
