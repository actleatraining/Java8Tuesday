package demo3;

public class Main {

    public static void main(String[] args) {
        Water water = new Water();
        System.out.println(water.howAreYouDoing());

        Pot pot = new Pot();
        pot.setWater(water);

        Stove stove = new Stove();
        stove.setPot(pot);
        stove.turnOn();

        System.out.println(water.howAreYouDoing());
    }
}
