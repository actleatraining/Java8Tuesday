package demo3;

public class Pot {
    private Water water;

    public void setWater(Water water) {
        this.water = water;
    }

    public boolean containsWater() {
        return water != null;
    }

    public void setIsHot(boolean isHot) {
        if (containsWater()) {
            this.water.setBoiling(true);
        }
    }
}
