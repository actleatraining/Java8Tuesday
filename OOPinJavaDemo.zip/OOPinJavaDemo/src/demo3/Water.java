package demo3;

public class Water {
    private boolean isBoiling = false;

    public void setBoiling(boolean isBoiling) {
        this.isBoiling = isBoiling;
    }

    public String howAreYouDoing() {
        /*
        if (isBoiling) {
            return "I’m boiling!";
        }
        else {
            return "I’m so cold!";
        }
         */
        return isBoiling ? "I’m boiling!" : "I’m so cold!";
    }
}
