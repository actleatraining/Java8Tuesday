package demo1part2;

import demo1.Dog;

public class Main {

    public static void main(String[] args) {

        Circle circle1 = new Circle();
        circle1.radius = 5;

        Circle circle2 = new Circle();
        circle2.radius = 13;

        System.out.println("circle1 area: " + circle1.getArea());
        System.out.println("circle1 perimeter: " + circle1.getPerimeter());

        System.out.println("circle2 area: " + circle2.getArea());
        System.out.println("circle2 perimeter: " + circle2.getPerimeter());
    }
}
