package demo5;

public class Main {
    public static void main(String[] args) {
        // primitive variable
        int number = 5;
        System.out.println(number);
        primitiveMethod(number);
        System.out.println(number); // the primitive variable is not affected by what happened in the other method

        // object variable
        Dog dog = new Dog();
        dog.name = "Pluto";
        System.out.println(dog.name);
        objectMethod(dog);
        System.out.println(dog.name); // // the object variable is affected by what happened in the other method
    }

    static void primitiveMethod(int number) {
        number = 99;
    }

    static void objectMethod(Dog dog) {
        dog.name = "Chicco";
    }
}
