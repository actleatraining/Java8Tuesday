package demo2;

// Static and non-static methods
public class Main {

    public static void main(String[] args) {

        // This static method can call another static method
        staticMethod("Hello!");

        // This static method can not call a non-static method - it is only accessible from an object reference
        //nonStaticMethod("Hello non-static!");

        // Create an objecto from the Main class
        Main main = new Main();

        // Then call the non-static object on the object reference main
        main.nonStaticMethod("Hello non-static!");

    }

    // Static method - belongs to the Class - accessible from static methods
    public static void staticMethod(String text) {
        System.out.println(text);
    }

    // Non-static method - belongs to the object - not accessible from static methods
    public void nonStaticMethod(String text) {
        System.out.println(text);
    }
}
