package demo2;

// Static and non-static - methods and variables, Dog class created to be a template for an object
public class Main2 {

    public static void main(String[] args) {

        // Access to static variable directly on Class Dog
        int converter = Dog.DOG_AGE_CONVERTER;

        // No access to non-static varible name on Class Dog
        //String name = Dog.name;

        // No access to non-static method bark on Class Dog
        //Dog.bark();

        // Need to create an object from the Dog class
        Dog dog = new Dog();

        // Access to non-static variable (ie Instance Variable) on dog object reference
        String name = dog.name;

        // Calling a non-static method on the object
        dog.bark();
    }
}
