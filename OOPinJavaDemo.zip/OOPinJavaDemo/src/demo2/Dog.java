package demo2;

public class Dog {
    String name;
    int age;
    static final int DOG_AGE_CONVERTER = 7;

    void bark() {
        System.out.println("Bark!");
    }

    int getDogAge() {
        return age * DOG_AGE_CONVERTER;
    }
}
