package demo1;

// Static and non-static - methods and variables, Dog class created to be a template for an object
public class Main {

    public static void main(String[] args) {

        // No access to non-static varible name on Class Dog
        // Dog.name = "Pluto";
        // String name = Dog.name;

        // Need to create an object from the Dog class
        Dog dog = new Dog();
        dog.name = "Pluto";

        // Access to non-static variable (ie Instance Variable) on dog object reference
        String name = dog.name;

        // dog.age = 4500000000; // No that's Pluto the dwarf planet, and you would need a long for that number!
        dog.age = 93; // Walt Disney Productions created Pluto the Pup as Mickey Mouse's pet dog in 1930

        System.out.println(dog.name);
        System.out.println(dog.age);

        // Calling a non-static method on the object
        dog.bark();

        // Array with dog objects
        Dog[] dogs = new Dog[2];
        dogs[0] = dog;
        dogs[1] = new Dog();
        dogs[1].name = "Chicco";

        for (Dog d : dogs) {
            System.out.println(d.name);
        }

    }
}
