package demo1;

public class Dog {
    String name;
    int age;

    void bark() {
        System.out.println("Bark!");
    }
}
