package exercise4;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of fruits:");
        int numberOfFruits = scanner.nextInt();

        //int[] fruitPrices = new int[numberOfFruits];
        //String[] fruitNames = new String[numberOfFruits];
        Fruit[] fruits = new Fruit[numberOfFruits];

        scanner.nextLine();

        for (int i = 0; i < numberOfFruits; i++) {
            Fruit fruit = new Fruit();
            System.out.println("Enter the name of the fruit:");
            fruit.name = scanner.nextLine();
            System.out.println("Enter the price of " + fruit.name + ":");
            fruit.price = scanner.nextInt();
            fruits[i] = fruit;
            scanner.nextLine();
        }

        //int cheapestPrice = fruitPrices[0];
        //int indexOfCheapestPrice = 0;
        Fruit cheapestFruit = fruits[0];
        for (int i = 1; i < fruits.length; ++i) {
            Fruit currentFruit = fruits[i];
            if (currentFruit.price < cheapestFruit.price) {
                //cheapestPrice = current;
                //indexOfCheapestPrice = i;
                cheapestFruit = currentFruit;
            }
        }

        //System.out.println("The cheapest fruit is the " + fruitNames[indexOfCheapestPrice] + " with the price " + cheapestPrice);
        System.out.println("The cheapest fruit is the " + cheapestFruit.name + " with the price " + cheapestFruit.price);
    }
}
