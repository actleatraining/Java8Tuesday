package exercise4;

public class Fruit {
    String name;
    int price;
}
