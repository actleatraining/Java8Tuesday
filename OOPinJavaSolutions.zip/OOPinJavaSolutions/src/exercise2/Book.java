package exercise2;

public class Book {
    String title;
    String author;
    int price;
}
