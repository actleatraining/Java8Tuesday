package exercise1;

public class Rectangle {
    int length;
    int width;

    public int getArea() {
        return length * width;
    }

    public int getPerimeter() {
        return length * 2 + width * 2;
    }
}
