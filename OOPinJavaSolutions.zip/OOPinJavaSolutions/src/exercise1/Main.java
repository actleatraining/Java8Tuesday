package exercise1;

public class Main {
    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle();
        rectangle1.length = 20;
        rectangle1.width = 15;

        Rectangle rectangle2 = new Rectangle();
        rectangle2.length = 35;
        rectangle2.width = 40;

        System.out.println("rectangle1 area: " + rectangle1.getArea());
        System.out.println("rectangle1 perimeter: " + rectangle1.getPerimeter());

        System.out.println("rectangle2 area: " + rectangle2.getArea());
        System.out.println("rectangle2 perimeter: " + rectangle2.getPerimeter());
    }
}