public class Demo2 {

    public static void main(String[] args) {

        String dogName1 = "Pluto";
        String dogName2 = "Pluto";

        if (dogName1 == dogName2) {
            System.out.println("1 and 2 Equals with ==");
        }

        if (dogName1.equals(dogName2)) {
            System.out.println("1 and 2 Equals with equals method");
        }

        String dogName3 = new String("Pluto");
        String dogName4 = new String("Pluto");

        if (dogName3 == dogName4) {
            System.out.println("3 and 4 Equals with ==");
        }

        if (dogName3.equals(dogName4)) {
            System.out.println("3 and 4 Equals with equals method");
        }

        if (dogName1.equals(dogName1)) {
            System.out.println("ja");
        }
    }
}
