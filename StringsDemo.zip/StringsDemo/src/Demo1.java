public class Demo1 {

    public static void main(String[] args) {

        // Creating a String
        String dogName = "Pluto";
        String myDog = new String("Chicco");

        // Returns the size (length) of a String
        int length = dogName.length();

        // Returns the character at index 2 (the third character)
        char c = dogName.charAt(2);

        // Returns the index of the first occurance of the character 't'
        int index = dogName.indexOf('t');

        // Returns true if the String is empty or false if it is not empty
        boolean isEmpty = dogName.isEmpty();

        // Returns true if the String ends with the substring "Y" or false if it doesn't
        boolean endsWithY = dogName.endsWith("Y");

        // Returns a copy of the String in lower case letters
        String dogNameLowercase = dogName.toLowerCase();
        
        String dogString = "Pluto ,    Chicco,Ludde    ,Another Dog";
        dogString = dogString.replace(" ", "");
        String[] dogArray = dogString.split(",");
        for (String dog : dogArray) {
            System.out.println(dog.trim());
        }

    }
}
