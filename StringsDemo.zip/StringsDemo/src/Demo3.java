public class Demo3 {

    public static void main(String[] args) {

        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" World");
        sb.append("!");
        System.out.println(sb);

        sb.replace(1, 3, "--");
        sb.delete(4,7);


        String string = sb.toString();
        System.out.println(string);

    }
}
