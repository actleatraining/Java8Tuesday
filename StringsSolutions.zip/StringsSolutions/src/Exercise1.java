public class Exercise1 {
    public static void main(String[] args) {
        String names = "apples,bananas,lemons";

        String[] fruits = names.split(",");

        for (String fruit : fruits) {
            System.out.println("Remember to buy " + fruit + "!");
        }
    }
}