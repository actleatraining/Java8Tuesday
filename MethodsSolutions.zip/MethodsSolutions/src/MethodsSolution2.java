import java.util.Arrays;

public class MethodsSolution2 {

    public static void main(String[] args) {
        int[] reversedNumbers = getReversedNumbers(1, 2, 3, 4, 5, 6, 7, 8, 9);

        System.out.println(Arrays.toString(reversedNumbers));
    }

    private static int[] getReversedNumbers(int... originalNumbers) {
        int[] reversedNumbers = new int[originalNumbers.length];
        for (int i = 0; i < originalNumbers.length; i++) {
            reversedNumbers[i] = originalNumbers[originalNumbers.length - 1 - i];
        }
        return reversedNumbers;
    }
}
