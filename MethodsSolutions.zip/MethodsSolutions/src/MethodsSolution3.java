public class MethodsSolution3 {

    public static void main(String[] args) {
        int[] numbers = {56,13,84,7,11,21,79};

        // Lowest number
        int lowestNumber = getLowestNumber(numbers);
        System.out.println("Lowest number: " + lowestNumber);

        // Highest number
        int highestNumber = getHighestNumber(numbers);
        System.out.println("Highest number: " + highestNumber);

        // Sum of the numbers
        int sum = getSum(numbers);
        System.out.println("Sum of numbers: " + sum);

        // Average of the numbers
        double average = getAverage(numbers);
        System.out.println("Average of numbers: " + average);
    }

    private static int getLowestNumber(int[] numbers) {
        int lowestSoFar = numbers[0];
        for (int i = 1; i < numbers.length; ++i) {
            int current = numbers[i];
            if (current < lowestSoFar) {
                lowestSoFar = current;
            }
        }
        return lowestSoFar;
    }

    private static int getHighestNumber(int[] numbers) {
        int highestSoFar = numbers[0];
        for (int i = 1; i < numbers.length; ++i) {
            int current = numbers[i];
            if (current > highestSoFar) {
                highestSoFar = current;
            }
        }
        return highestSoFar;
    }

    private static int getSum(int[] numbers) {
        int sum = 0;
        for (int i = 0; i < numbers.length; ++i) {
            double current = numbers[i];
            sum += current;
        }
        return sum;
    }

    private static double getAverage(int[] numbers) {
        int sum = getSum(numbers);
        double average = sum / numbers.length;
        return average;
    }
}
